INSERT INTO Storage2(book_name,id,isbn,aisle,author) values('Cypress','abcd4','abcd','4','Rahul');
INSERT INTO Storage2(book_name,id,isbn,aisle,author) values('Devops','fdsefr343','fdsefr3','43','Rahul');
INSERT INTO Storage2(book_name,id,isbn,aisle,author) values('Devops','ddy22','ddy','22','Shetty');
